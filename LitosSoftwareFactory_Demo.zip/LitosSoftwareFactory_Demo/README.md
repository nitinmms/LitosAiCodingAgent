# Litos Software Factory — interactive demo

This is the exported HTML/CSS/JavaScript prototype, including project lessons.
It simulates agent work, token budgets, build/unit-test results and handoff.
It never opens a repository, calls an AI model or connects to a database.

## Run locally

1. Extract this entire ZIP.
2. Open a terminal in this folder.
3. With Python 3 installed, run `py -3 serve.py` on Windows or
   `python3 serve.py` on macOS/Linux.
4. Open http://127.0.0.1:8080 in your browser.

Use `--port 8090` to select another port. Stop with Ctrl+C.
No npm packages or build step are required. Do not open the HTML using a
file:// URL; JavaScript modules need an HTTP server.

## Try lessons

Click **Lessons → Try export example → Remember for project → Try on a new task**.
Send the prefilled `@factory` message and see the lesson included in its context.
You can edit, disable or dismiss lessons and open their source threads.
Accepting a completed simulated task also produces a suggested lesson, subject
to the simulated token allowance. Complete its three human-test checkboxes first.

Use “Try a scenario” on a new thread to explore human decisions, budget
exhaustion and a simulated unit-test repair. Same-directory tasks retain a review
hold until acceptance or cancellation.

## Files

- `app/index.html`: page shell and new-thread dialog.
- `app/app.js`: user interface, browser storage and lesson integration.
- `app/engine.mjs`: simulated task lifecycle, budgets and workspace scheduling.
- `app/lessons.mjs`: suggestions, approval checks and project/topic matching.
- `app/styles.css`, `app/lessons.css`: interface styles.
- `serve.py`: loopback-only local static server.
- `ReadMe_LitosSoftwareFactory_V1.md`: revised production blueprint, including
  PostgreSQL factory state, approved lessons, recovery and implementation order.

The PostgreSQL/.NET backend is specified in the blueprint, not implemented here.
Demo data is stored only in this browser and origin using localStorage. The
hosted demo and localhost have separate data. Reset playground clears local
threads and lessons. Do not enter credentials or sensitive information.

Source export: `e9b679269587e4b604a424ca7b1ebd1a3987e64f`.
Packaged 29 September 2026. Hosting-specific metadata and Git history omitted.
