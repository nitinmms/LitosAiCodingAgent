# Litos.SoftwareFactory — Version 1 Blueprint

Date: 29 September 2026
Revision: 2 — PostgreSQL factory state and approved project lessons
Status: Proposed implementation design, not a claim about existing Litos APIs.

The accompanying ZIP is the working browser prototype, including lessons. It uses localStorage and simulated workers. PostgreSQL, the .NET coordinator, actual Litos execution and the production contracts below are implementation targets, not features already implemented in that ZIP.

## 1. Product definition

A local, chat-driven software factory that delegates a change request to Litos coding agents, edits the selected working directory, builds the code and runs unit tests, then returns the result to the same thread for human application testing.

One change or feature = one thread. A user-authored `@factory` mention delegates work. The factory works until it produces a reviewable result, needs a human decision, encounters a blocker, is stopped, or cannot continue within the task's token allowance.

The human tests the running application and decides whether the task is accepted. Passing unit tests never means the feature has passed application testing.

## 2. Scope and explicit exclusions

### Included

- One physical machine; local repositories and folders.
- User/agent chat, with a separate thread per feature or change.
- Working-directory selection and clear display of the exact execution path.
- `@factory` delegation, optional cumulative task token budget, pause/resume/cancel.
- Reuse of the existing Litos agent engine and provider adapters.
- Code inspection, edits, dependency restore, compilation and unit tests.
- Human decisions, durable checkpoints, progress, diffs and test evidence in-thread.
- Human testing handoff and same-thread rework.
- Durable factory state and approved project lessons in a dedicated PostgreSQL database.
- Suggested lessons with source evidence, explicit human approval, editing, disabling and relevant retrieval.

### Deferred

- EC2, Spot workers, AMIs, per-task Docker environment provisioning and VM cloning.
- Automated UI, browser, API, integration, database and end-to-end testing.
- Application startup, deployment, automatic commits, pushes, PRs and merges.
- Live database migration execution, seed-data changes or database baseline promotion.
- Autonomous agent teams, distributed queues, visual workflow designers.

The factory may write migration scripts when the task needs them. Execution against a database and verification of the resulting application behavior are human responsibilities in V1. Docker is optional for the factory-state PostgreSQL service; an existing PostgreSQL installation can host a separate factory database. This does not authorize database access for coding tasks.

## 3. Recommended V1 defaults

| Decision | Default |
| --- | --- |
| Workspace behavior | Edit the selected working directory directly |
| Concurrency | One active run globally initially; always one write owner per directory/repository group |
| Agent execution | One Litos worker session per run; sequential reasoning/edit/verification stages |
| UI | Local Blazor Server chat UI; can later be hosted through the existing Avalonia shell |
| Host | Local ASP.NET Core service with durable coordinator and worker-process adapter |
| Factory state and lessons | Dedicated PostgreSQL database `litos_factory`, outside target application databases |
| Memory scope | Stable project ID; approved, enabled, relevant lessons only |
| Budget | Optional task cap; omitted means no explicit task cap, not unlimited retries |
| Completion | Factory returns `AwaitingHumanTesting`; user marks `Accepted` |
| Git delivery | Leave a reviewable diff; user handles commits and integration |

These are recommendations, not extra requirements from the user. V1 should optimize for one reliable complete workflow.

## 4. Main user flow

1. Create a thread and give it a title.
2. Select a working directory with a local folder picker.
3. Optionally choose a model and set a maximum task token budget.
4. Discuss the feature with Litos. Ordinary discussion does not authorize factory editing.
5. Send `@factory Add a CSV export button to the Orders page. Only administrators can use it.`
6. The host captures the request, applicable thread decisions, workspace, budget and verification profile, and snapshots relevant approved project lessons.
7. The factory acknowledges the task, obtains the workspace lock, posts a concise plan and starts.
8. It reads relevant code, makes the change, builds and runs configured unit tests.
9. It posts a result with the diff, evidence and manual testing instructions.
10. The user tests the application and either accepts the task or requests further work in the same thread.
11. After acceptance, the factory may propose up to three reusable lessons within the remaining task budget. The user can Remember, Edit or Dismiss each proposal. Explicit user-written lessons can be saved without any model call.

There is no mandatory plan-approval pause for every task. Ask only when a material choice cannot reasonably be inferred, an operation needs new authority, or the user explicitly requests plan review.

### Example thread

User: `@factory Add CSV export for Orders. Administrator access only. Budget: 120,000 tokens.`

Factory: `Assigned. Workspace: C:\Projects\SalesApp. I will inspect authorization, implement export, and run the unit-test profile. Application testing will be yours.`

Factory: `Decision needed: should export include all filtered rows or only the current page? No further edits will run until you answer.`

User: `All filtered rows.`

Factory resumes the waiting run using that answer if budget remains.

Factory: `Ready for human testing. Build passed. 18 unit tests passed. Review the diff, then check administrator export, non-administrator access, filters, and an empty result.`

User: `@factory CSV values containing commas are incorrect. Fix this.`

Factory reopens implementation on the same task with the remaining cumulative budget.

User: `Accept` (structured action) marks the tested result accepted. A normal chat message is not silently treated as acceptance.

## 5. Thread and dispatch semantics

- A TaskThread is the durable conversation and the home of one logical task.
- A TaskRun is one execution attempt/resumption segment. Several runs may belong to a thread.
- Assignment is a structured composer mention rendered as `@factory`. A parser may also recognize an explicit user-authored leading mention; quoted text, code blocks, assistant messages and tool output must never trigger delegation.
- A unique message ID is the dispatch idempotency key. Double-clicks or network retries create only one assignment.
- Starting a run snapshots the user request and accepted corrections into a versioned task specification.
- One active run per thread. A mention during execution becomes a follow-up instruction, not a second simultaneous run.
- Steering messages enter an inbox and are incorporated at a safe tool boundary. Pause/cancel controls go directly to the host.
- A response to a specific open decision resumes that decision when unambiguous. Other paused states require an explicit Resume action or `@factory` request.
- Budget exhaustion cannot be bypassed by posting `@factory` again. The user must raise/remove the cap or explicitly start a separate task.
- Working directory is fixed while a task has changes or is awaiting testing. Changing projects creates a new thread; do not carry old diffs into a new folder.

## 6. Workspace ownership and preservation

V1 edits in place. This is operational separation, not an OS security sandbox. Do not advertise absolute isolation.

Before editing:

1. Canonicalize the path, resolve aliases/junctions for lock identity and validate access.
2. Detect Git root, branch and starting commit when available.
3. Inventory tracked modifications and relevant untracked files. Respect exclusions for secrets and large/generated files.
4. Require a clean Git working directory by default. If dirty, explain the specific condition and let the user clean it or explicitly authorize working on top of recorded changes. Never auto-stash, commit, reset or discard them.
5. For non-Git folders, create before-images for every file before editing; track created/deleted files and retain a task patch manifest.
6. Record a clean baseline build/unit-test result when feasible so pre-existing failures are distinguishable.

Lock the canonical workspace and, conservatively, its Git repository group. This also prevents overlapping parent/child selections or separate aliases from running together. If busy, queue the thread and show the owner.

Retain a review hold while a task awaits human testing, a decision, or more tokens: another factory task must not modify the same directory. The UI can offer explicit release with a warning that the existing review baseline will become stale. There is no automatic timeout that silently frees it for edits.

External edits by the user remain possible. Before writing a previously read file, compare its version/hash. On conflict, reread and reconcile or ask; never overwrite silently. Record diff hashes at handoff and invalidate test evidence when the content changes.

If concurrent work on the same repository becomes necessary, add Git worktrees later as an explicit workspace mode. Directories alone do not isolate databases or external side effects.

## 7. Coordinator and state machine

Persist state in PostgreSQL; do not depend on the agent's chat memory to decide task status.

```mermaid
stateDiagram-v2
    Draft --> Queued: user delegates
    Queued --> Running: lock and worker acquired
    Running --> AwaitingDecision: human choice needed
    AwaitingDecision --> Queued: answer received
    Running --> PausedBudget: allowance insufficient
    PausedBudget --> Queued: cap increased and resumed
    Running --> PausedUser: user pauses
    PausedUser --> Queued: user resumes
    Running --> Blocked: environment or verification blocker
    Blocked --> Queued: blocker resolved
    Running --> AwaitingHumanTesting: handoff saved
    AwaitingHumanTesting --> Queued: user requests rework
    AwaitingHumanTesting --> Accepted: user accepts
    Running --> Interrupted: host or worker lost
    Interrupted --> Queued: explicit recovery
    Queued --> Cancelled: user cancels
    Running --> Cancelled: user cancels
```

Pause/cancel also apply to waiting states. Cancellation preserves edits and evidence; it does not revert files. Acceptance likewise does not commit or merge code.

Track verification separately from lifecycle: build `NotRun/Passed/Failed/Unavailable`, unit tests `NotRun/Passed/Failed/NoTests/Unavailable`, and human testing `NotStarted/Passed/Failed`. A result can be handed off with explicitly disclosed limitations, but never labeled unit-test-passed when tests did not run.

## 8. Execution loop and deterministic boundaries

Coordinator responsibilities:

- Scheduling, workspace ownership and lifecycle transitions.
- Message ordering, budget accounting, process timeouts and cancellation.
- Invoking known verification commands and recording exit codes/results.
- Persisting checkpoints and posting status/decision/result messages.

Litos responsibilities:

- Understand requirements and inspect relevant code.
- Choose implementation details within the approved scope.
- Modify code and meaningful unit tests.
- Diagnose failures, make bounded repairs and explain the result.

Do not implement fixed orchestration decisions as LLM conversations. Reuse existing Litos tools/provider/context handling; introduce a factory host adapter around them rather than copying the agent loop. A separate planner or reflection agent service is not required in V1.

Proposed execution sequence: preflight -> inspect -> concise plan -> implement -> build -> unit tests -> bounded repair -> handoff. Start with at most two repair cycles after the initial verification failure; persistent repeated failures become Blocked even if tokens remain. Add configurable command and run wall-clock limits to prevent no-progress hangs.

Routine internal coding tools retain Litos's existing auto-approval behavior. Factory execution is governed by a scoped run contract: selected workspace, configured commands, no app testing/deployment/target-application database writes. The trusted factory host persists its own state through PostgreSQL; this capability is not exposed as an agent SQL tool. This is not a new per-tool permission UI. MCP permissions continue to follow Litos.Api's existing model.

For V1's automatic runs, expose only needed tools; avoid browser/computer-use or live database tools. Command restrictions are host safeguards, not proof against hostile code executing under the same OS user.

## 9. Token-budget contract

The optional cap belongs to the logical task/thread and spans planning, coding, repair, summarization, lesson reflection and rework. It includes every model request made on behalf of that task, even if additional agent roles are introduced later. Task-execution retries count when usage is incurred. Ordinary pre-assignment discussion is shown separately.

Define task tokens as provider-reported input plus output, including cached input and reasoning tokens where reported. Do not double-count cache/reasoning fields already included in totals. This is a token allowance, not a currency or context-window limit; repeated prompt input consumes budget again even if cached pricing is cheaper. Show provider/model breakdown and optionally estimated monetary cost separately.

### Enforce before dispatch

1. Read used tokens and any reservations atomically.
2. Estimate the next request's complete input, including system instructions, tools and history.
3. Reserve that input plus a bounded output allowance and a configurable estimation margin.
4. Set the provider's output limit to fit the remaining allowance.
5. If a useful request cannot fit, pause before making it; do not wait to hit exactly zero.
6. Reconcile the reservation against reported usage after the response.

Provider accounting and tokenizer differences mean a universal exact hard ceiling cannot be promised. Use provider-specific estimation, output caps and conservative admission. If usage is unknown after a timeout, keep its reservation pending or conservatively charged until reconciled; never silently refund it to enable unbounded retries. Providers unable to bound/report adequately must show an estimated-budget warning or be disabled for strict-budget mode.

All model calls must pass through the same budget gate, including compaction, reflection and retry calls. Retrieved lesson text contributes to model input usage like any other context. Reserve a small handoff allowance if useful; when no tokens remain, generate a deterministic report from saved state without another LLM call.

On exhaustion: stop dispatching new model work, let a bounded in-flight operation finish or time out safely, preserve changes, then post progress, last verification, used/limit, and next action. Do not start a repair cycle. A user action changes the cumulative maximum (for example 120,000 -> 160,000), not the accounting history.

When no cap is specified, still enforce cancellation, iteration/no-progress and time limits. Display usage throughout.

## 10. Verification: builds and unit tests only

A build is a compilation check, not application testing. It is allowed and recommended. Dependency restore/install needed to compile follows project policy and is recorded.

Configure explicit unit-test projects or a reviewed filter. Do not blindly run `dotnet test` on a solution that also contains database/integration/UI suites. A label or project name alone does not prove tests are isolated; review the profile at onboarding.

Example proposed profile (illustrative schema owned by Litos):

```json
{
  "profileVersion": 1,
  "workingDirectory": "C:\\Projects\\SalesApp",
  "build": { "executable": "dotnet", "arguments": ["build", "SalesApp.sln"], "timeoutSeconds": 600 },
  "unitTests": [
    { "executable": "dotnet", "arguments": ["test", "tests/SalesApp.UnitTests/SalesApp.UnitTests.csproj", "--no-build"], "timeoutSeconds": 300 }
  ],
  "applicationTesting": "human",
  "databaseExecution": "disabled",
  "maximumRepairCycles": 2
}
```

Use argument arrays, not concatenated shell commands. Treat repository-provided verification/config changes as untrusted until the host/user accepts them; an agent cannot redefine the gate to make its own task pass. Keep execution results attached to the exact code diff.

For Web Forms use the installed MSBuild and an appropriate unit-test runner through the same generic profile. The factory does not launch IIS/IIS Express. For Blazor it does not run the web application or browser tests. The human starts and tests either application.

Write behavior-focused unit tests when the change supports them; avoid meaningless tests mirroring the implementation. If no test infrastructure exists, report this explicitly and ask before a substantial framework introduction. Never invent passing counts.

## 11. Human decisions and handoff

Decision cards include: question, why it blocks work, concrete options, recommendation where appropriate, impacted files/behavior, and a decision ID. Stop the active run while awaiting the answer. Persist the answer in the task specification.

Examples: ambiguous business rule; conflicting user edits; required package/dependency outside agreed scope; no usable unit-test setup; a proposed destructive data operation (which remains manual in V1).

Handoff contains:

- What changed and which acceptance criteria it addresses.
- Changed files and baseline-relative diff.
- Exact build/unit-test commands, results, duration and whether tests were pre-existing/new.
- Pre-existing failures, unverified behavior and known limitations.
- Any migration scripts plus explicit `Not applied / not database-tested` labeling.
- Manual test steps, expected results and required setup.
- Cumulative tokens used and remaining.
- Actions: Accept, Request changes, Resume (where applicable), Open folder, View diff, View logs.

Manual testing checklist is generated guidance, not evidence of testing. User feedback reopens the task. If there is insufficient budget, collect feedback but wait for a budget adjustment before invoking a model.

## 12. UI structure

Three regions:

| Region | Contents |
| --- | --- |
| Left | New thread, thread titles, status badges, search/filter |
| Center | Conversation, compact progress events, decisions, handoff, composer with @factory |
| Right or collapsible details | Working directory, task status, model, token allowance/usage, changed files, build and unit-test results, lessons included in this run |
| Project lessons panel | Pending suggestions, approved/enabled lessons, source links, revisions, Remember/Edit/Dismiss/Disable actions |

Before delegation, the composer shows the selected path and optional budget. During execution show Pause and Cancel. In budget pause show Change budget and Resume. In human testing show Accept and Request changes.

Post meaningful stage changes, not every thought or tool output. Large tool results live in log artifacts with bounded excerpts in chat. Keep the system/tool prefix stable and send only relevant task state back to Litos to preserve prompt-cache usefulness.

## 13. Suggested local architecture

```text
Browser / optional Avalonia shell
  -> Local Factory API and event stream
     -> Thread service + durable task coordinator
        -> Workspace lock manager
        -> Budget gate and usage ledger
        -> Litos worker process adapter
        -> Build / unit-test runner
     -> Lesson service: propose, approve, retrieve, snapshot
     -> PostgreSQL factory state + local artifact files
```

Use one ASP.NET Core host and a dedicated PostgreSQL database initially. Run the host and worker natively on Windows for access to local repositories, MSBuild and unit-test runners. PostgreSQL may run in one Docker Desktop Linux container, or use a separately configured database on an existing PostgreSQL service. Workers do not receive the factory database connection string. In-memory queues may wake the scheduler, but persisted task state is authoritative. A separate child worker process per active run improves crash/cancel handling; it is not a security sandbox. The existing Litos engine should remain reusable outside this factory.

Suggested boundaries, without requiring a project per class:

```text
Litos.SoftwareFactory.Web       chat UI and local API
Litos.SoftwareFactory.Core      coordinator, states, policies, budget
Litos.SoftwareFactory.Infrastructure  PostgreSQL, filesystem, Git, process adapters
Litos.SoftwareFactory.Worker    headless host for existing Litos runtime
```

Bind locally by default, authenticate local UI/API requests, and check browser origins. Do not expose the controller to the LAN by default. Store provider credentials through the existing secret mechanism, not in thread JSON or generated configuration files.

## 14. Minimum persisted records

| Record | Important fields |
| --- | --- |
| Project | Stable UUID, name, repository identity if available, created/updated timestamps |
| Workspace | ID, project ID, machine ID, canonical execution path and lock-group ID |
| TaskThread | ID, project ID, workspace ID, title, state, specification revision, budget cap, timestamps |
| Message | ID, thread ID, role/type, text, sequence, dispatch key, decision reference |
| TaskRun | ID, thread ID, status, baseline commit/manifest, worker ID, checkpoint, heartbeat, stop reason |
| Decision | ID, run ID, question/options, status, answer message |
| UsageEntry | Request ID, run ID, provider/model, input/output, accounting basis, reserved/actual/unknown status |
| ToolExecution | ID, run ID, command/tool, start/end, exit code, artifact reference |
| Verification | Run ID, profile revision, result, counts, command, diff hash, log reference |
| ChangeSet | Baseline, file manifest, before-images/patch, current content hashes |
| WorkspaceLease | Unique canonical group, owning thread, active/review hold, heartbeat and recovery-required flag |
| ProjectLesson | ID, project ID, current revision, status, enabled flag, source thread/run/message, evidence |
| LessonRevision | Lesson ID, revision, immutable text/topics/scope, editor, approval attribution and timestamps |
| RunLessonSnapshot | Run ID, lesson ID/revision, copied text, retrieval reason, inclusion time |
| ReflectionJob | ID, thread ID, accepted specification revision, status, request/usage reference, retry state |
| OutboxEvent | ID, thread/project ID, payload, sequence, created and delivered timestamps |

Use durable event sequence IDs so clients reconnect and replay missed updates. Persist state transitions and outgoing notifications together (outbox pattern) so a crash cannot silently lose a decision or handoff.

## 15. Host/worker contract (proposed)

StartRun input: task/run IDs, workspace, task specification, checkpoint reference, model settings, approved lesson snapshot, verification profile, allowed capabilities and budget-gateway reference. The worker must not carry an independent unrestricted provider path that bypasses accounting.

Worker events: StageChanged, ToolStarted, ToolFinished, UsageRecorded, DecisionRequested, CheckpointSaved, ResultReady, Faulted. Host actions: Start, Pause, Resume, Cancel, AnswerDecision, UpdateBudget.

The host validates terminal results against its own verification records. An agent's text saying tests passed cannot override a non-zero test exit code or missing evidence.

Persist checkpoints after meaningful edits, tool completion, decisions and stage transitions. Store task specification, progress, modified-file hashes, last command outcome, next action, and references to detailed logs. Do not serialize credentials into checkpoints.

## 16. Crash, pause and recovery behavior

- Host restart: reconcile leases with actual process liveness; mark interrupted work, do not blindly rerun it.
- Worker crash: preserve files and logs; offer Resume after checking current workspace and usage reservations.
- Pause: stop new tool/model dispatch, settle a running bounded operation, checkpoint.
- Cancel: terminate the managed process tree where safe, report interrupted commands, preserve edits.
- Unknown command result: inspect before retrying. Commands may have side effects even if no success event was received.
- Recovery: compare file hashes and current branch to checkpoint; explain conflicts before continuing.
- If a unit-test run was interrupted, report it as incomplete, not failed/passed evidence.
- A local disk failure remains a V1 durability limit; normal user backups are separate from task checkpointing.

## 17. Build order

1. Chat threads, folder picker and `@factory` dispatch with a stub worker.
2. PostgreSQL state, idempotent dispatch, queue and workspace ownership.
3. Headless Litos adapter, event streaming and cancellation.
4. Budget ledger/gateway and deterministic exhausted-budget handoff.
5. Configured build and unit-test execution with evidence.
6. Human decision cards, result diff, human testing and rework.
7. Project identity, lesson CRUD/approval/retrieval and immutable run snapshots.
8. Budgeted reflection with durable job status and idempotent proposal creation.
9. Recovery, external-file-conflict handling and acceptance validation.

Do not add multi-worker concurrency before the entire loop works. Later allow different independent directories to run concurrently, with a shared model/resource limit. Keep one write owner per repository group in V1.

## 18. Acceptance scenarios for the factory itself

1. A normal chat message never starts editing; one explicit assignment starts exactly one run.
2. The requested small feature produces a diff and real unit-test evidence, then waits for human testing.
3. Two threads selecting the same directory cannot run simultaneously or overwrite a pending review.
4. A decision pauses execution and a linked answer resumes it without losing context.
5. A small token allowance prevents another unaffordable request; deterministic handoff still appears.
6. Increasing a cap preserves prior usage and resumes the same task.
7. A provider timeout with unknown usage cannot silently refund the entire allowance.
8. A failing unit test triggers bounded repair; persistent failure is reported honestly.
9. No target-application integration tests, app startup or live application-database changes occur under the unit-test-only profile. Trusted factory-state persistence is separate.
10. Host/worker restart recovers files and task state without duplicating unsafe operations.
11. External edits trigger reconciliation; cancellation never discards user changes.
12. Accept records human approval without committing, pushing or deploying.
13. A pending, dismissed or disabled lesson is never retrieved; another project's lesson never leaks into the run.
14. Editing a lesson preserves the original text in past run snapshots.
15. Reflection cannot exceed the task budget or block acceptance; explicit manual lesson saving requires no model call.
16. Duplicate messages, acceptance events or reflection retries cannot create duplicate runs or proposals.
17. Database loss stops new dispatch; recovery does not steal a workspace from a live worker.
18. Restored state and artifact backups can reconstruct threads, evidence and lessons; unresolved runs resume only after reconciliation.

## 19. Definition of success

The first demo should be one local repo, one chat thread, one `@factory` feature request, a visible token allowance, implementation, build and unit-test results, followed by a human testing checklist. The user reports a problem in the same thread, the factory repairs it within the remaining allowance, and the user accepts.

An additional success criterion is that an approved correction from one accepted task appears in a relevant later task, and the user can inspect why it was included.

The product promise is: delegate a bounded coding task, see its progress and evidence, and remain in control of decisions and application acceptance.

## 20. PostgreSQL: factory state, not the application's database

Use one dedicated database named `litos_factory`. It holds the coordinator's records, conversations, decisions, usage, workspace ownership and lessons for all registered projects. It is not cloned per task and is not used as a target application's test database. A task changing an ERP schema produces migration files for human execution; it must not run those files against the factory database.

Use a PostgreSQL persistence adapter in the host, with Npgsql and an explicitly versioned schema. EF Core is an implementation option, not a requirement. Keep relational columns for IDs, ownership, lifecycle, revisions, budgets and timestamps; use JSONB for bounded structured payloads such as checkpoints and verification details. Store large logs, patches and before-images in a factory-owned artifact directory, with relative paths, sizes and hashes recorded in PostgreSQL. Do not store provider keys or database passwords in messages, lessons or checkpoints.

### Local deployment choices

| Choice | Configuration |
| --- | --- |
| Existing PostgreSQL on port 5432 | Create a separate `litos_factory` database and scoped runtime role; no extra container needed |
| Dedicated PostgreSQL container | Expose `127.0.0.1:5433` to avoid the existing application database on 5432; use a persistent volume |
| Factory host and worker | Run on Windows initially so the selected folders and installed build tools are accessible |

The following is an optional development infrastructure example, not a backend included in the demo. Save it as `compose.factory-state.yml` alongside a private `.env` file. The PostgreSQL 18 image uses a volume mounted at `/var/lib/postgresql`; use a tested immutable image digest when making deployments reproducible.

```yaml
services:
  factory-db:
    image: postgres:18
    restart: unless-stopped
    environment:
      POSTGRES_DB: litos_factory
      POSTGRES_USER: factory_admin
      POSTGRES_PASSWORD: ${FACTORY_DB_ADMIN_PASSWORD:?Set FACTORY_DB_ADMIN_PASSWORD}
    ports:
      - "127.0.0.1:5433:5432"
    volumes:
      - factory_state:/var/lib/postgresql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U factory_admin -d litos_factory"]
      interval: 5s
      timeout: 5s
      retries: 12
volumes:
  factory_state:
```

Run `docker compose -f compose.factory-state.yml up -d`. The initialization user is an administrative bootstrap account. Provision a separate `factory_runtime` role with only the required table/sequence permissions after migrations; never give the coding worker this credential. Keep schema-owner/migration credentials separate. Changing initialization environment variables does not rotate credentials inside an existing data volume.

For a native Windows host, configure `ConnectionStrings__FactoryState` through its private environment/secret configuration:

```text
Host=127.0.0.1;Port=5433;Database=litos_factory;Username=factory_runtime;Password=<runtime-secret>
```

Use port 5432 instead when choosing the existing PostgreSQL service. If the host is containerized later, connect by Compose service name and port 5432 on its network, not by the host's loopback address. Do not put connection strings in browser code. Do not remove the named volume to update the factory.

### Transaction and concurrency rules

1. Persist the user message, assignment idempotency key, specification revision and queued state in one transaction.
2. Claim queued work in a short transaction. Lock the task and acquire the unique workspace ownership record, validate the global worker limit, create the run and record its initial state/outbox event before commit. Do not hold a database transaction open while invoking Litos or build tools.
3. In V1, enforce a singleton local coordinator and a durable global execution-slot record as well as workspace ownership. Later, `FOR UPDATE SKIP LOCKED` can help multiple consumers claim eligible queue rows; it does not replace workspace exclusion or the global worker limit.
4. Reserve and reconcile model usage while holding the thread's budget row lock. Use a unique provider-request/accounting key so repeated callbacks cannot double-charge tokens.
5. Commit a state transition, checkpoint reference and outbox event atomically. Deliver events at least once; clients deduplicate using event IDs and replay using durable sequence numbers.
6. Use optimistic revision checks for user actions. Stale acceptance, decision answers or lesson edits return a conflict instead of overwriting a newer revision.
7. Database unavailability stops new model/tool dispatch. Let already running bounded commands settle, record their outcome locally if possible, and reconcile before continuing. A heartbeat timeout alone must never authorize a second writer while an old process may still be alive.

Workspace ownership survives a coordinator connection loss. A durable review hold has no automatic expiry. Recover execution leases by confirming local process identity/liveness and inspecting checkpoints; keep the workspace blocked if its previous writer cannot be accounted for. A session advisory lock alone is insufficient for this hold.

### Required constraints and indexes

- Primary keys are stable UUIDs; represent timestamps with `timestamptz` and use UTC for stored event times.
- Unique `(thread_id, message_sequence)` and a unique dispatch idempotency key.
- Unique live write ownership per canonical workspace/repository group; resolve overlapping directory groups before granting ownership.
- Enforce at most one active execution attempt per thread and the configured global slot count.
- Unique usage request key; nonnegative token counts/caps stored as `bigint`.
- Unique `(lesson_id, revision)` and `(run_id, lesson_id)` snapshot identity.
- Unique reflection job identity `(thread_id, accepted_specification_revision)`; unique `(reflection_job_id, proposal_ordinal)` for generated suggestions.
- Index queued task eligibility, project/state lesson lookups, thread message sequences, undelivered outbox events and artifact ownership.
- Include project identity in validation of every related thread, source, lesson and run. Use composite foreign keys where suitable so a source thread from another project cannot be attached accidentally.

These are schema requirements. This blueprint does not supply a complete production migration or claim database integration has been implemented.

## 21. Lessons: the V1 self-improvement loop

The factory improves by retaining reviewed, reusable guidance across tasks. It does not train a model or autonomously rewrite its own policies.

### What to remember

| Suitable lesson | Why it is reusable |
| --- | --- |
| In this ERP, CSV exports include all filtered rows unless the task requests a subset | Business behavior corrected by a human |
| In this project, quantity rounding happens at the service boundary using the documented rule | Project convention with a source |
| Use the existing authorization helper for administration actions | Repeated implementation guidance |

Avoid secrets, raw logs, copied stack traces, transient build failures, speculative conclusions, complete source files and one-off instructions with no ongoing relevance. Facts about implementation locations may become stale; verify the current code before relying on them.

### Proposed lifecycle

`Suggested -> Approved` or `Suggested -> Dismissed`. Approved lessons may be disabled, edited into a new revision, re-enabled or superseded by an explicitly linked replacement. Pending suggestions are never execution context.

1. At acceptance, persist the accepted code/specification revision and a reflection job independently of the accepted state.
2. If useful evidence and budget exist, the same Litos adapter proposes zero to three lessons. Zero is a valid result. Include the human correction/decision or accepted evidence behind each suggestion; do not manufacture a lesson merely because a task passed.
3. Display the rule, scope, topics, source and reason in the thread. Offer **Remember for project**, **Edit**, and **Dismiss**.
4. A structured user approval activates exactly the reviewed revision. Saving an agent-generated draft is not approval. A direct user-created lesson may use a clearly labeled **Save and approve** action.
5. On later delegation, retrieve a bounded set of relevant approved lessons and copy their exact versions into the new run context.
6. Show which lessons were included and allow the user to open their sources or disable outdated guidance for future runs.

The initial project scope is a stable `ProjectId`, not a folder string. Workspaces map that identity to paths. A moved folder can be re-associated explicitly; two unrelated directories with similar names are not automatically treated as the same project. Do not automatically share lessons across projects or infer identity only from a repository URL.

### Source, history and edits

Store each lesson's project, author/proposer, origin (`Human` or `AgentSuggestion`), source thread/run/message, evidence excerpt, creation time, status and enabled flag. Each immutable revision holds the rule, topic tags, optional component/path applicability, editor and timestamp. Approval records the approving user and exact revision.

Editing an approved lesson is an explicit user approval of the edited revision when the UI says **Save approved revision**. The agent can only propose a replacement; it cannot approve or overwrite approved guidance. Keep previous versions and run snapshots unchanged. Disabling affects future retrieval; a user who needs to change a running task must steer or pause it explicitly.

Normalize text to detect exact duplicate proposals within the same project. Present possible semantic duplicates or contradictions for review; never silently merge or discard materially different business rules. A replacement may explicitly supersede an old lesson in one transaction.

## 22. Lesson retrieval and context assembly

Start with deterministic topic matching over approved, enabled lessons in the task's project. Match against the current request and task title, then rank by topic overlap and explicit component/path applicability. Stable tie-breaking makes selection reproducible. Do not require embeddings, a vector database or another model call in V1.

Suggested configurable defaults: at most five lessons and at most 1,500 input tokens, also constrained by the task's remaining budget and available context. These are starting settings to evaluate, not model limits. A user can explicitly select a relevant lesson that keyword matching missed. Report excluded lessons when they were manually selected but could not fit.

Assemble context in this order:

1. Stable system/tool instructions.
2. Fixed factory execution contract and approved verification profile.
3. Retrieved project lessons, marked as guidance with IDs, revision numbers and evidence links.
4. Current task request, human decisions and current code/tool context.

Keep the stable prefix unchanged; use a separate run-level lesson section. Actual prompt-cache behavior depends on the provider. Snapshot once when starting a run; resume the same run with its recorded snapshot. Refresh on a new rework run or explicit user request, with the change visible in the thread.

Authority comes from the host's policy, not just prompt order: permissions, scope and token enforcement always apply. Current explicit user instructions override remembered preferences when allowed by that policy. If a lesson and current evidence reveal a material ambiguity, ask a concrete question instead of silently guessing. A lesson cannot enable integration tests, database writes, deployment or unlimited tokens.

Record each included lesson's ID, revision, copied text, retrieval reason and inclusion time in `RunLessonSnapshot`. A later edit or deletion policy must not rewrite the historical explanation of what the worker received. Usage records include the tokens consumed by this context.

## 23. Reflection jobs, budgets and proposed API

Reflection is a small optional job through the existing Litos runtime. It does not need a dedicated permanent worker or a planner/coder agent team. Charge its model usage to the accepted thread's cumulative budget through the same budget gateway.

Suggested reflection states: `Pending`, `Running`, `DeferredBudget`, `Completed`, `Failed`, `Skipped`. Commit acceptance first. Reflection failure or insufficient budget cannot undo acceptance or retain the workspace write hold. Reflection uses persisted evidence and cannot modify the target repository.

If a reflection call times out, retain unknown usage reservations until reconciled. Retry only within the budget and bounded retry policy. Persist generated proposals together with job completion, using stable proposal identities so a crash/retry cannot append duplicates. An empty valid proposal list also completes the job.

No-budget UI: “Task accepted. Lesson reflection is deferred; increase the allowance, add a lesson manually, or skip.” Manual lesson entry is deterministic and costs no model tokens. The demo's 600-token reflection is an illustrative fixed charge, not a production estimate.

Proposed host API (new contracts to implement, not existing Litos endpoints):

| Operation | Contract |
| --- | --- |
| List project lessons | `GET /api/projects/{projectId}/lessons` with status filter |
| Create human proposal | `POST /api/projects/{projectId}/lessons` with text, topics and optional source |
| Approve | `POST /api/lessons/{id}/approve` with expected revision and idempotency key |
| Edit | `POST /api/lessons/{id}/revisions` with expected revision and explicit approval intent |
| Dismiss / enable / disable | Explicit commands with expected revision and an audit event |
| Inspect run context | `GET /api/runs/{runId}/lessons` returns recorded snapshots |
| Retry / skip reflection | Explicit thread reflection action subject to budget and job state |

Authenticate every call and verify project ownership/access in the host. The worker submits suggestions through a constrained host interface; it cannot write SQL, mark its own lessons approved or change budgets. Browser storage is only UI preference/cache in the production design; PostgreSQL is authoritative.

## 24. Migrations, backups and operations

Version the factory schema in its own migration history, separate from any application's Flyway history. Choose one migration authority for the factory: reviewed Flyway SQL scripts, or EF Core migrations if that is the persistence stack. Do not let both independently manage the same schema. Released migrations are immutable; add forward corrective migrations and take a backup before destructive changes.

Run factory schema upgrades through a trusted deployment/setup command before starting normal dispatch, using the migration role. A coding task must never trigger arbitrary migrations of the factory's database. Pin the supported schema/application compatibility and fail clearly when they disagree.

Back up the factory PostgreSQL database and its artifact directory as a consistent pair. For a simple V1 maintenance backup: pause dispatch, settle active commands, stop the host, create a custom-format `pg_dump`, copy referenced immutable artifacts plus a manifest, then restart. Retain backups outside the machine and periodically restore into a separate database and artifact location. A Docker image contains the database engine, not the latest factory records; a named volume alone is not a backup.

On restore, mark unfinished runs interrupted, reconcile workspaces and unknown usage, validate artifact hashes and require explicit recovery. Do not automatically replay file edits or external commands. Restoring factory state does not restore target repositories; keep repository backups/version control separately.

Useful operational counters: queued/running/paused tasks, oldest pending decision, unreconciled reservations, last heartbeat, outbox backlog, reflection failures, accepted task count, and repeat human corrections. Record lesson inclusion separately from evidence that it helped; retrieval count alone is not proof of improvement. Let users flag “helpful”, “outdated” or “wrong” feedback before considering automated scoring in later versions.

## 25. Demo ZIP: what is implemented and how to run

The archive `LitosSoftwareFactory_Demo.zip` contains the exported browser demo source from commit `e9b679269587e4b604a424ca7b1ebd1a3987e64f`, this revised blueprint and a small local server launcher. No hosting credentials or Git history are included. The source files are plain HTML, CSS and JavaScript modules; there is no npm installation or build step.

Extract the ZIP, open a terminal in `LitosSoftwareFactory_Demo`, and run:

```powershell
py -3 serve.py
```

On macOS/Linux use `python3 serve.py`. Open `http://127.0.0.1:8080`. Python 3 is required for this launcher. To choose another port, use `py -3 serve.py --port 8090`. Stop with Ctrl+C. Serve through HTTP; do not double-click `index.html`, because browser module loading may fail on a file URL.

The launcher binds only to loopback and serves `app/`. It explicitly configures JavaScript module MIME types. This is a local demo server, not the future production factory host.

| Included behavior | Demo implementation | Production target |
| --- | --- | --- |
| Threads, assignment and stages | Browser state machine and timers | PostgreSQL coordinator + Litos worker |
| Workspace selection | Typed path label, simulated locks | Validated local folder picker and durable ownership |
| Builds, changes, unit tests | Illustrative outputs and scenarios | Actual commands, diffs and recorded evidence |
| Budgets | Fixed simulated stage charges | Provider usage, reservations and reconciliation |
| Lessons | Approval/edit/disable, source links and keyword matching | PostgreSQL lesson revisions and audited retrieval |
| Persistence | localStorage in this browser/origin | PostgreSQL plus artifact files |
| Reflection | Example rule or recorded feedback text | Budgeted evidence-based model proposal |

Try **Lessons -> Try export example -> Remember for project -> Try on a new task**, then send the prefilled `@factory` request. Alternatively complete a simulated task, tick its human-test checklist and accept to see a suggested lesson. The demo's suggested rules are examples for review, not reliable deductions from real code execution.

Saved state is specific to a browser profile and origin: the hosted demo and localhost do not share it, nor do different localhost ports. Clearing browser data or selecting Reset playground removes the local demo state. It does not touch any real repository or database. Do not enter secrets in the demo.

Prototype limitations retained in this export: one active task globally; project matching uses normalized working-directory strings; no durable revision history for lesson edits; context snapshots preserve included text, but the production audit/schema is not implemented. A pending manually created empty lesson must be edited before approval. Backend endpoint names, tables and PostgreSQL setup in this document are design guidance, not executable factory services bundled in the ZIP.

## 26. Technical references

Implementation recommendations in this blueprint are design decisions. The following primary sources support the PostgreSQL operational details (checked 29 September 2026):

- PostgreSQL 18 SELECT and queue-row locking: https://www.postgresql.org/docs/18/sql-select.html
- PostgreSQL SQL dump backups: https://www.postgresql.org/docs/18/backup-dump.html
- Official PostgreSQL Docker image, initialization and PostgreSQL 18 volume layout: https://hub.docker.com/_/postgres

Before production release, validate the coordinator, schema migrations and restore process against the pinned dependency versions. The static demo does not establish production correctness.
