export const stages=['Inspect workspace','Plan the change','Implement','Build','Run unit tests','Prepare handoff'];
export const costs=[1200,2400,3600,2100,1800,900];
export const labels={Draft:'Not assigned',Queued:'Queued',Running:'Factory working',AwaitingDecision:'Decision needed',PausedBudget:'Budget paused',PausedUser:'Paused',AwaitingHumanTesting:'Human testing',Accepted:'Accepted',Cancelled:'Cancelled'};
export const holding=new Set(['Running','AwaitingDecision','PausedBudget','PausedUser','AwaitingHumanTesting']);
export function makeThread(title,path,budget=24000,scenario='success'){
  return {id:globalThis.crypto?.randomUUID?.()||String(Date.now()+Math.random()),title,path,budget:scenario==='budget'?5000:budget,scenario,status:'Draft',used:0,step:0,messages:[],activity:[],decisionDone:false,repairPending:false,repaired:false,build:'Not run',tests:'Not run',hasChanges:false,iteration:1,request:'',checklist:[false,false,false]};
}
export function addMessage(t,role,text,kind='text'){t.messages.push({role,text,kind,time:Date.now()});}
const canonical=p=>p.trim().replaceAll('/','\\').replace(/\\+$/,'').toLowerCase();
export function conflicts(a,b){const x=canonical(a),y=canonical(b);return x===y||x.startsWith(y+'\\')||y.startsWith(x+'\\');}
export function blocker(threads,t){return threads.find(x=>x.id!==t.id&&holding.has(x.status)&&conflicts(x.path,t.path));}
export function schedule(threads){if(threads.some(t=>t.status==='Running'))return;const t=threads.find(t=>t.status==='Queued'&&!blocker(threads,t));if(t){t.status='Running';addMessage(t,'factory',t.step===0?'Workspace reserved. I’ll inspect the request, make the change, build, and run unit tests. You’ll handle application testing.':'Continuing from the saved checkpoint.','event');}}
export function assign(threads,t,request){
  if(t.status==='Accepted'||t.status==='Cancelled')throw Error('Create a new thread for another task.');
  if(t.status==='PausedBudget')throw Error('Increase or remove the token cap, then resume.');
  if(t.status==='Running'||t.status==='Queued') {addMessage(t,'user',request);addMessage(t,'factory','Follow-up recorded. It will be considered at the next step.','event');return;}
  if(t.status==='AwaitingDecision')throw Error('Answer the pending decision first.');
  if(t.status==='AwaitingHumanTesting'){t.step=2;t.iteration++;t.checklist=[false,false,false];t.build='Not run';t.tests='Not run';t.hasChanges=false;t.repairPending=false;}
  t.request=request;addMessage(t,'user',request);t.status='Queued';schedule(threads);
}
export function tick(threads){
  schedule(threads);const t=threads.find(x=>x.status==='Running');if(!t)return;
  if(t.scenario==='decision'&&t.step===1&&!t.decisionDone){t.status='AwaitingDecision';addMessage(t,'factory','Before I implement this, how should I handle the scope of the change?','decision');return;}
  const cost=t.repairPending?3500:costs[t.step];
  if(t.budget!==null&&t.used+cost>t.budget){t.status='PausedBudget';addMessage(t,'factory',`Paused before the next model request. It needs approximately ${cost.toLocaleString()} tokens, but only ${(t.budget-t.used).toLocaleString()} remain. Your changes and checkpoint are preserved.`,'budget');return;}
  t.used+=cost;
  if(t.repairPending){t.repairPending=false;t.repaired=true;t.activity.push({label:'Repair unit-test failure',cost});addMessage(t,'factory','Fixed the simulated edge-case failure and added a regression assertion. Running the unit tests again.','event');return;}
  const phase=t.step;t.activity.push({label:stages[phase],cost});
  const notes=['Inspected the simulated workspace and existing project conventions. No external services will be started.','Plan: implement the requested behavior, cover its core logic with unit tests, and leave application verification to you.','Implementation prepared. Sample file changes are available in the Changes panel.','Build passed in this simulation. The application has not been started.','Unit tests passed: 18 passed, 0 failed. Integration, UI and database tests were not run.','Ready for your review and application testing.'];
  if(phase===2)t.hasChanges=true;
  if(phase===3)t.build='Passed';
  if(phase===4&&t.scenario==='repair'&&!t.repaired){t.tests='1 failed';t.repairPending=true;addMessage(t,'factory','Unit tests: 17 passed, 1 failed. A simulated edge case failed. Starting one bounded repair cycle.','event');return;}
  if(phase===4)t.tests='18 passed';
  t.step++;
  if(phase===5){t.status='AwaitingHumanTesting';addMessage(t,'factory',notes[phase],'result');}
  else addMessage(t,'factory',notes[phase],phase===1?'text':'event');
}
export function decide(threads,t,answer){if(t.status!=='AwaitingDecision')throw Error('This thread has no pending decision.');t.decisionDone=true;addMessage(t,'user',answer);addMessage(t,'factory','Decision saved. Continuing with that scope.','event');t.status='Queued';schedule(threads);}
export function resume(threads,t){if(!['PausedBudget','PausedUser'].includes(t.status))throw Error('This task is not paused.');const needed=t.repairPending?3500:costs[t.step];if(t.budget!==null&&t.used+needed>t.budget)throw Error(`Raise the cap to at least ${(t.used+needed).toLocaleString()} tokens to continue.`);t.status='Queued';schedule(threads);}
export function accept(t){if(t.status!=='AwaitingHumanTesting')throw Error('The task is not ready for acceptance.');if(!t.checklist.every(Boolean))throw Error('Complete the three human-testing checks first.');t.status='Accepted';addMessage(t,'user','Human testing completed. I accept this change.');addMessage(t,'factory','Accepted. Workspace hold released. No commit, push or deployment was performed.','event');}
